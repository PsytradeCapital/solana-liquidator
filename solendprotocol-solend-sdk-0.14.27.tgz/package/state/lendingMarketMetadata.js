"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseLendingMarketMetadata = exports.LENDING_MARKET_METADATA_SIZE = exports.LendingMarketMetadataLayout = void 0;
const fzstd = __importStar(require("fzstd"));
const Layout = __importStar(require("../layout"));
const anchor = __importStar(require("@coral-xyz/anchor"));
const BufferLayout = require("buffer-layout");
exports.LendingMarketMetadataLayout = BufferLayout.struct([
    BufferLayout.u8("bumpSeed"),
    BufferLayout.blob(50, "marketName"),
    BufferLayout.blob(300, "marketDescription"),
    BufferLayout.blob(250, "marketImageUrl"),
    BufferLayout.blob(32 * 4, "lookupTables"),
    BufferLayout.blob(100, "padding"),
]);
exports.LENDING_MARKET_METADATA_SIZE = exports.LendingMarketMetadataLayout.span;
function trimString(array) {
    const firstEndingZeroIndex = array.findIndex((value, index) => value === 0 && array.slice(index).every(v => v === 0));
    const trimmedArray = firstEndingZeroIndex === -1 ? array : array.slice(0, firstEndingZeroIndex);
    return anchor.utils.bytes.utf8.decode(trimmedArray);
}
const parseLendingMarketMetadata = (pubkey, info, encoding) => {
    if (encoding === "base64+zstd") {
        info.data = Buffer.from(fzstd.decompress(info.data));
    }
    const { data } = info;
    const buffer = Buffer.from(data);
    const lendingMarketMetadata = exports.LendingMarketMetadataLayout.decode(buffer);
    const lookupTables = BufferLayout.seq(Layout.publicKey(), 4).decode(lendingMarketMetadata.lookupTables);
    const details = {
        pubkey,
        account: {
            bumpSeed: lendingMarketMetadata.bumpSeed,
            marketName: trimString(Buffer.from(lendingMarketMetadata.marketName)),
            marketDescription: trimString(Buffer.from(lendingMarketMetadata.marketDescription)),
            marketImageUrl: trimString(Buffer.from(lendingMarketMetadata.marketImageUrl)),
            lookupTables,
        },
        info: lendingMarketMetadata,
    };
    return details;
};
exports.parseLendingMarketMetadata = parseLendingMarketMetadata;
