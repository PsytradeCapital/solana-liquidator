/// <reference types="node" />
/// <reference types="node" />
/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { AccountInfo, PublicKey } from "@solana/web3.js";
declare const BufferLayout: any;
export declare const LendingMarketMetadataLayout: typeof BufferLayout.Structure;
export interface LendingMarketMetadata {
    bumpSeed: number;
    marketName: string;
    marketDescription: string;
    marketImageUrl: string;
    lookupTables: Buffer;
}
export type ParsedLendingMarketMetadata = ReturnType<typeof parseLendingMarketMetadata>;
export declare const LENDING_MARKET_METADATA_SIZE: any;
export declare const parseLendingMarketMetadata: (pubkey: PublicKey, info: AccountInfo<Buffer>, encoding?: string) => {
    pubkey: PublicKey;
    account: {
        bumpSeed: number;
        marketName: string;
        marketDescription: string;
        marketImageUrl: string;
        lookupTables: any;
    };
    info: LendingMarketMetadata;
};
export {};
