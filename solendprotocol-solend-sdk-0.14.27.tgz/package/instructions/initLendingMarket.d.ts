/// <reference types="node" />
/// <reference types="node" />
/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { PublicKey, TransactionInstruction } from "@solana/web3.js";
export declare const initLendingMarketInstruction: (owner: PublicKey, quoteCurrency: Buffer, lendingMarket: PublicKey, lendingProgramId: PublicKey, oracleProgramId: PublicKey, switchboardProgramId: PublicKey) => TransactionInstruction;
