/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { PublicKey, TransactionInstruction } from "@solana/web3.js";
export declare const repayMaxObligationLiquidityInstruction: (sourceLiquidity: PublicKey, destinationLiquidity: PublicKey, repayReserve: PublicKey, obligation: PublicKey, lendingMarket: PublicKey, transferAuthority: PublicKey, solendProgramAddress: PublicKey) => TransactionInstruction;
