"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.liquidateObligationAndRedeemReserveCollateral = void 0;
// @ts-nocheck
const spl_token_1 = require("@solana/spl-token");
const web3_js_1 = require("@solana/web3.js");
const bn_js_1 = __importDefault(require("bn.js"));
const BufferLayout = __importStar(require("buffer-layout"));
const Layout = __importStar(require("../layout"));
const instruction_1 = require("./instruction");
/// Repay borrowed liquidity to a reserve to receive collateral at a discount from an unhealthy
/// obligation. Requires a refreshed obligation and reserves.
/// Accounts expected by this instruction:
///   0. `[writable]` Source liquidity token account.
///                     Minted by repay reserve liquidity mint.
///                     $authority can transfer $liquidity_amount.
///   1. `[writable]` Destination collateral token account.
///                     Minted by withdraw reserve collateral mint.
///   2. `[writable]` Destination liquidity token account.
///   3. `[writable]` Repay reserve account - refreshed.
///   4. `[writable]` Repay reserve liquidity supply SPL Token account.
///   5. `[writable]` Withdraw reserve account - refreshed.
///   6. `[writable]` Withdraw reserve collateral SPL Token mint.
///   7. `[writable]` Withdraw reserve collateral supply SPL Token account.
///   8. `[writable]` Withdraw reserve liquidity supply SPL Token account.
///   9. `[writable]` Withdraw reserve liquidity fee receiver account.
///   10 `[writable]` Obligation account - refreshed.
///   11 `[]` Lending market account.
///   12 `[]` Derived lending market authority.
///   13 `[signer]` User transfer authority ($authority).
///   14 `[]` Token program id.
const liquidateObligationAndRedeemReserveCollateral = (liquidityAmount, sourceLiquidity, destinationCollateral, destinationRewardLiquidity, repayReserve, repayReserveLiquiditySupply, withdrawReserve, withdrawReserveCollateralMint, withdrawReserveCollateralSupply, withdrawReserveLiquiditySupply, withdrawReserveFeeReceiver, obligation, lendingMarket, lendingMarketAuthority, transferAuthority, solendProgramAddress) => {
    const dataLayout = BufferLayout.struct([
        BufferLayout.u8("instruction"),
        Layout.uint64("liquidityAmount"),
    ]);
    const data = Buffer.alloc(dataLayout.span);
    dataLayout.encode({
        instruction: instruction_1.LendingInstruction.LiquidateObligationAndRedeemReserveCollateral,
        liquidityAmount: new bn_js_1.default(liquidityAmount),
    }, data);
    const keys = [
        { pubkey: sourceLiquidity, isSigner: false, isWritable: true },
        { pubkey: destinationCollateral, isSigner: false, isWritable: true },
        { pubkey: destinationRewardLiquidity, isSigner: false, isWritable: true },
        { pubkey: repayReserve, isSigner: false, isWritable: true },
        { pubkey: repayReserveLiquiditySupply, isSigner: false, isWritable: true },
        { pubkey: withdrawReserve, isSigner: false, isWritable: true },
        {
            pubkey: withdrawReserveCollateralMint,
            isSigner: false,
            isWritable: true,
        },
        {
            pubkey: withdrawReserveCollateralSupply,
            isSigner: false,
            isWritable: true,
        },
        {
            pubkey: withdrawReserveLiquiditySupply,
            isSigner: false,
            isWritable: true,
        },
        { pubkey: withdrawReserveFeeReceiver, isSigner: false, isWritable: true },
        { pubkey: obligation, isSigner: false, isWritable: true },
        { pubkey: lendingMarket, isSigner: false, isWritable: true },
        { pubkey: lendingMarketAuthority, isSigner: false, isWritable: false },
        { pubkey: transferAuthority, isSigner: true, isWritable: false },
        { pubkey: spl_token_1.TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
    ];
    return new web3_js_1.TransactionInstruction({
        keys,
        programId: solendProgramAddress,
        data,
    });
};
exports.liquidateObligationAndRedeemReserveCollateral = liquidateObligationAndRedeemReserveCollateral;
