/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { PublicKey, TransactionInstruction } from "@solana/web3.js";
import BN from "bn.js";
import { InputReserveConfigParams } from "../core";
export declare const initReserveInstruction: (liquidityAmount: number | BN, config: InputReserveConfigParams, sourceLiquidity: PublicKey, destinationCollateral: PublicKey, reserve: PublicKey, liquidityMint: PublicKey, liquiditySupply: PublicKey, liquidityFeeReceiver: PublicKey, collateralMint: PublicKey, collateralSupply: PublicKey, pythPrice: PublicKey, switchboardFeed: PublicKey, lendingMarket: PublicKey, lendingMarketAuthority: PublicKey, lendingMarketOwner: PublicKey, transferAuthority: PublicKey, lendingProgramId: PublicKey) => TransactionInstruction;
