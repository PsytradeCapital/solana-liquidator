/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { PublicKey, TransactionInstruction } from "@solana/web3.js";
import BN from "bn.js";
export declare const withdrawExact: (liquidityAmount: number | BN, reserveCollateral: PublicKey, userCollateral: PublicKey, withdrawReserve: PublicKey, userLiquidity: PublicKey, reserveCollateralMint: PublicKey, reserveLiquiditySupply: PublicKey, obligation: PublicKey, lendingMarket: PublicKey, lendingMarketAuthority: PublicKey, obligationOwner: PublicKey, transferAuthority: PublicKey, solendProgramAddress: PublicKey, depositReserves: Array<PublicKey>) => TransactionInstruction;
