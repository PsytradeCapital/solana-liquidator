/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { PublicKey, TransactionInstruction } from "@solana/web3.js";
import { RateLimiterConfig } from "../state/rateLimiter";
import { InputReserveConfigParams } from "../core";
export declare const updateReserveConfig: (reserve: PublicKey, lendingMarket: PublicKey, lendingMarketAuthority: PublicKey, lendingMarketOwner: PublicKey, pythPrice: PublicKey, switchboardOracle: PublicKey, reserveConfig: InputReserveConfigParams, rateLimiterConfig: RateLimiterConfig, solendProgramAddress: PublicKey) => TransactionInstruction;
