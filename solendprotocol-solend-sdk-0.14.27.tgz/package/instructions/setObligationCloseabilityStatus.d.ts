/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { PublicKey, TransactionInstruction } from "@solana/web3.js";
export declare const setObligationCloseabilityStatus: (obligation: PublicKey, lendingMarket: PublicKey, reserve: PublicKey, riskAuthority: PublicKey, closeable: boolean, lendingProgramId: PublicKey) => TransactionInstruction;
