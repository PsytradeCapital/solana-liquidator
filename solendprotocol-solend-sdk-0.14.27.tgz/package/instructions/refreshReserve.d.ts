/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { PublicKey, TransactionInstruction } from "@solana/web3.js";
export declare const refreshReserveInstruction: (reserve: PublicKey, solendProgramAddress: PublicKey, oracle: PublicKey, switchboardFeedAddress?: PublicKey, extraOracle?: PublicKey) => TransactionInstruction;
