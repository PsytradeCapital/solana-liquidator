"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setObligationCloseabilityStatus = void 0;
const web3_js_1 = require("@solana/web3.js");
const instruction_1 = require("./instruction");
const BufferLayout = require("buffer-layout");
const setObligationCloseabilityStatus = (obligation, lendingMarket, reserve, riskAuthority, closeable, lendingProgramId) => {
    const dataLayout = BufferLayout.struct([
        BufferLayout.u8("instruction"),
        BufferLayout.u8("closeable"),
    ]);
    const data = Buffer.alloc(dataLayout.span);
    dataLayout.encode({
        instruction: instruction_1.LendingInstruction.SetObligationCloseabilityStatus,
        closeable: closeable ? 1 : 0,
    }, data);
    const keys = [
        { pubkey: obligation, isSigner: false, isWritable: true },
        { pubkey: lendingMarket, isSigner: false, isWritable: false },
        { pubkey: reserve, isSigner: false, isWritable: false },
        { pubkey: riskAuthority, isSigner: true, isWritable: true },
    ];
    return new web3_js_1.TransactionInstruction({
        keys,
        programId: lendingProgramId,
        data,
    });
};
exports.setObligationCloseabilityStatus = setObligationCloseabilityStatus;
