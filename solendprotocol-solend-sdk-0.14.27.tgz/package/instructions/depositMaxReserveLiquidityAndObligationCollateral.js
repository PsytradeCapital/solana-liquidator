"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.depositMaxReserveLiquidityAndObligationCollateralInstruction = void 0;
const spl_token_1 = require("@solana/spl-token");
const web3_js_1 = require("@solana/web3.js");
const constants_1 = require("../core/constants");
const BufferLayout = require("buffer-layout");
/// Deposit liquidity into a reserve in exchange for collateral, and deposit the collateral as well.
const depositMaxReserveLiquidityAndObligationCollateralInstruction = (sourceLiquidity, sourceCollateral, reserve, reserveLiquiditySupply, reserveCollateralMint, lendingMarket, lendingMarketAuthority, destinationCollateral, obligation, obligationOwner, pythOracle, switchboardFeedAddress, transferAuthority, solendProgramAddress) => {
    const dataLayout = BufferLayout.struct([BufferLayout.u8("instruction")]);
    const data = Buffer.alloc(dataLayout.span);
    dataLayout.encode({
        instruction: 2,
    }, data);
    const keys = [
        { pubkey: solendProgramAddress, isSigner: false, isWritable: false },
        { pubkey: sourceLiquidity, isSigner: false, isWritable: true },
        { pubkey: sourceCollateral, isSigner: false, isWritable: true },
        { pubkey: reserve, isSigner: false, isWritable: true },
        { pubkey: reserveLiquiditySupply, isSigner: false, isWritable: true },
        { pubkey: reserveCollateralMint, isSigner: false, isWritable: true },
        { pubkey: lendingMarket, isSigner: false, isWritable: true },
        { pubkey: lendingMarketAuthority, isSigner: false, isWritable: false },
        { pubkey: destinationCollateral, isSigner: false, isWritable: true },
        { pubkey: obligation, isSigner: false, isWritable: true },
        { pubkey: obligationOwner, isSigner: true, isWritable: false },
        { pubkey: pythOracle, isSigner: false, isWritable: false },
        { pubkey: switchboardFeedAddress, isSigner: false, isWritable: false },
        { pubkey: transferAuthority, isSigner: true, isWritable: false },
        { pubkey: spl_token_1.TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
    ];
    return new web3_js_1.TransactionInstruction({
        keys,
        programId: constants_1.WRAPPER_PROGRAM_ID,
        data,
    });
};
exports.depositMaxReserveLiquidityAndObligationCollateralInstruction = depositMaxReserveLiquidityAndObligationCollateralInstruction;
