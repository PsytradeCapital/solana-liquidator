/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { Connection, PublicKey } from "@solana/web3.js";
import { EnvironmentType, PoolMetadataCoreType } from "../../index";
export declare function fetchPoolMetadata(connection: Connection, environment?: EnvironmentType, customApiHost?: string, useApi?: Boolean, debug?: Boolean): Promise<Array<PoolMetadataCoreType>>;
export declare const fetchPoolMetadataFromChain: (connection: Connection, programId: PublicKey, debug?: Boolean) => Promise<{
    name: string;
    owner: string;
    authorityAddress: string;
    address: string;
    reserves: never[];
}[]>;
