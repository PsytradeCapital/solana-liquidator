/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { Connection } from "@solana/web3.js";
export declare const fetchTokensInfo: (mints: string[], connection: Connection, debug?: boolean) => Promise<any>;
