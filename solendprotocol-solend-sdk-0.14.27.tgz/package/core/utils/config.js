"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchPoolMetadataFromChain = exports.fetchPoolMetadata = void 0;
const web3_js_1 = require("@solana/web3.js");
const index_1 = require("../../index");
const constants_1 = require("../constants");
const axios_1 = __importDefault(require("axios"));
async function fetchPoolMetadata(connection, environment = "production", customApiHost, useApi, debug) {
    if (debug)
        console.log("fetchConfig");
    const programId = (0, index_1.getProgramId)(environment);
    if (!useApi)
        return (0, exports.fetchPoolMetadataFromChain)(connection, programId, debug);
    try {
        const configResponse = await axios_1.default.get(`${customApiHost ?? "https://api.save.finance"}/v1/markets/configs?scope=all&deployment=${environment === "mainnet-beta" ? "production" : environment}`);
        const configData = configResponse.data;
        return configData;
    }
    catch (e) {
        return (0, exports.fetchPoolMetadataFromChain)(connection, programId, debug);
    }
}
exports.fetchPoolMetadata = fetchPoolMetadata;
const fetchPoolMetadataFromChain = async (connection, programId, debug) => {
    if (debug)
        console.log("fetchPoolsFromChain");
    const filters = [{ dataSize: index_1.LENDING_MARKET_SIZE }];
    const pools = Array.from(await connection.getProgramAccounts(programId, {
        commitment: connection.commitment,
        filters,
        encoding: "base64",
    }));
    return pools
        .sort((a, _b) => a.account.owner.toBase58() === constants_1.SOLEND_ADDRESSES[0] ? 1 : -1)
        .map((pool) => {
        const [authorityAddress, _bumpSeed] = web3_js_1.PublicKey.findProgramAddressSync([pool.pubkey.toBytes()], programId);
        return {
            name: pool.pubkey.toBase58(),
            owner: pool.account.owner.toBase58(),
            authorityAddress: authorityAddress.toBase58(),
            address: pool.pubkey.toBase58(),
            reserves: [],
        };
    });
};
exports.fetchPoolMetadataFromChain = fetchPoolMetadataFromChain;
