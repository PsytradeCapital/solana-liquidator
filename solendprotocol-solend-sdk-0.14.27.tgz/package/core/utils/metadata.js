"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchTokensInfo = void 0;
const utl_sdk_1 = require("@solflare-wallet/utl-sdk");
const web3_js_1 = require("@solana/web3.js");
const fetchTokensInfo = async (mints, connection, debug) => {
    if (debug)
        console.log("getTokensInfo");
    const defaultConfig = new utl_sdk_1.Client();
    const utl = new utl_sdk_1.Client({
        ...defaultConfig.config,
        connection,
    });
    const tokens = await utl.fetchMints(mints.map((mint) => new web3_js_1.PublicKey(mint)));
    return Object.fromEntries(tokens
        .map((token) => token
        ? [
            token.address,
            {
                symbol: token.symbol,
                logoUri: token.logoURI,
                decimals: token.decimals ?? 0,
            },
        ]
        : [])
        .filter((x) => x.length));
};
exports.fetchTokensInfo = fetchTokensInfo;
