"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchPrices = void 0;
const web3_js_1 = require("@solana/web3.js");
const client_1 = require("@pythnetwork/client");
const pyth_solana_receiver_1 = require("@pythnetwork/pyth-solana-receiver");
const utils_1 = require("./utils");
const nodewallet_1 = __importDefault(require("@coral-xyz/anchor/dist/cjs/nodewallet"));
const SBV2_MAINNET = "SW1TCH7qEPTdLsDHRgPuMQjbQxKdH2aBStViMFnt64f";
async function fetchPrices(parsedReserves, connection, switchboardProgram, debug) {
    if (debug)
        console.log("fetchPrices");
    const oracles = parsedReserves
        .map((reserve) => reserve.info.liquidity.pythOracle)
        .concat(parsedReserves.map((reserve) => reserve.info.liquidity.switchboardOracle));
    const priceAccounts = await (0, utils_1.getBatchMultipleAccountsInfo)(oracles, connection);
    const pythSolanaReceiver = new pyth_solana_receiver_1.PythSolanaReceiver({
        connection,
        wallet: new nodewallet_1.default(web3_js_1.Keypair.fromSeed(new Uint8Array(32).fill(1))),
    });
    return parsedReserves.reduce((acc, reserve, i) => {
        const pythOracleData = priceAccounts[i];
        const switchboardOracleData = priceAccounts[parsedReserves.length + i];
        let priceData;
        if (pythOracleData) {
            if (pythOracleData.owner.toBase58() ===
                pythSolanaReceiver.receiver.programId.toBase58()) {
                const priceUpdate = pythSolanaReceiver.receiver.account.priceUpdateV2.coder.accounts.decode("priceUpdateV2", pythOracleData.data);
                const exponent = 10 ** priceUpdate.priceMessage.exponent;
                const spotPrice = priceUpdate.priceMessage.price.toNumber() * exponent;
                const emaPrice = priceUpdate.priceMessage.emaPrice.toNumber() * exponent;
                priceData = {
                    spotPrice,
                    emaPrice,
                };
            }
            else {
                const { price, previousPrice, emaPrice } = (0, client_1.parsePriceData)(pythOracleData.data);
                if (price || previousPrice) {
                    // use latest price if available otherwise fallback to previous
                    priceData = {
                        spotPrice: price || previousPrice,
                        emaPrice: emaPrice?.value ?? (price || previousPrice),
                    };
                }
            }
        }
        // Only attempt to fetch from switchboard if not already available from pyth
        if (!priceData) {
            const rawSb = switchboardOracleData;
            const switchboardData = switchboardOracleData?.data?.slice(1);
            if (rawSb && switchboardData) {
                const owner = rawSb.owner.toString();
                if (owner === SBV2_MAINNET) {
                    const result = switchboardProgram.decodeLatestAggregatorValue(rawSb);
                    priceData = {
                        spotPrice: result?.toNumber() ?? 0,
                        emaPrice: result?.toNumber() ?? 0,
                    };
                }
            }
        }
        return {
            ...acc,
            [reserve.pubkey.toBase58()]: priceData,
        };
    }, {});
}
exports.fetchPrices = fetchPrices;
