"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchWalletAssets = exports.formatWalletAssets = void 0;
const spl_token_1 = require("@solana/spl-token");
const web3_js_1 = require("@solana/web3.js");
const bignumber_js_1 = __importDefault(require("bignumber.js"));
const utils_1 = require("./utils");
function formatWalletAssets(rawWalletData, metadata, nativeTokenSymbol = "SOL") {
    const { userAssociatedTokenAccounts, wSolAddress, nativeSolBalance } = rawWalletData;
    const assets = userAssociatedTokenAccounts
        .map((parsedAccount) => {
        if (!parsedAccount)
            return null;
        const mintAddress = parsedAccount.mint.toBase58();
        const tokenMetadata = metadata[mintAddress];
        const decimals = tokenMetadata?.decimals ?? 0;
        return {
            decimals,
            symbol: tokenMetadata?.symbol === nativeTokenSymbol
                ? `w${nativeTokenSymbol}`
                : tokenMetadata?.symbol,
            address: parsedAccount.address.toBase58(),
            amount: new bignumber_js_1.default(parsedAccount.amount.toString()).shiftedBy(-decimals),
            mintAddress: tokenMetadata?.symbol === nativeTokenSymbol
                ? `w${nativeTokenSymbol}`
                : mintAddress,
            logoUri: tokenMetadata?.logoUri,
            underlyingToken: tokenMetadata?.underlyingToken,
        };
    })
        .filter(Boolean);
    const nativeMetadata = metadata[spl_token_1.NATIVE_MINT.toBase58()];
    return assets.concat([
        {
            decimals: Math.log10(web3_js_1.LAMPORTS_PER_SOL),
            symbol: nativeTokenSymbol,
            address: wSolAddress,
            amount: nativeSolBalance,
            mintAddress: spl_token_1.NATIVE_MINT.toBase58(),
            logo: nativeMetadata?.logoUri ??
                "https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png",
        },
    ]);
}
exports.formatWalletAssets = formatWalletAssets;
async function fetchWalletAssets(uniqueAssets, publicKey, connection, debug) {
    if (debug)
        console.log("fetchWalletAssets", uniqueAssets.length);
    const uniqueAssetAccounts = await (0, utils_1.getBatchMultipleAccountsInfo)(uniqueAssets.map((asset) => new web3_js_1.PublicKey(asset)), connection);
    const userTokenAssociatedAddresses = await Promise.all(uniqueAssetAccounts.map(async (asset, index) => {
        const userTokenAccount = await (0, spl_token_1.getAssociatedTokenAddress)(new web3_js_1.PublicKey(uniqueAssets[index]), new web3_js_1.PublicKey(publicKey), true, asset?.owner.toBase58() === spl_token_1.TOKEN_2022_PROGRAM_ID.toBase58()
            ? spl_token_1.TOKEN_2022_PROGRAM_ID
            : undefined);
        return userTokenAccount;
    }));
    const userAssociatedTokenAccounts = await (0, utils_1.getBatchMultipleAccountsInfo)(userTokenAssociatedAddresses, connection);
    const nativeSolBalance = await connection.getBalance(new web3_js_1.PublicKey(publicKey));
    const wSolAddress = (await (0, spl_token_1.getAssociatedTokenAddress)(spl_token_1.NATIVE_MINT, new web3_js_1.PublicKey(publicKey), true)).toBase58();
    return {
        userAssociatedTokenAccounts: userAssociatedTokenAccounts.map((account, index) => account
            ? (0, spl_token_1.unpackAccount)(userTokenAssociatedAddresses[index], account, account?.owner.toBase58() === spl_token_1.TOKEN_2022_PROGRAM_ID.toBase58()
                ? spl_token_1.TOKEN_2022_PROGRAM_ID
                : undefined)
            : null),
        nativeSolBalance: new bignumber_js_1.default(nativeSolBalance).dividedBy(web3_js_1.LAMPORTS_PER_SOL),
        wSolAddress,
    };
}
exports.fetchWalletAssets = fetchWalletAssets;
