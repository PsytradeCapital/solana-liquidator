/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { AddressLookupTableAccount, Connection, PublicKey, TransactionInstruction, VersionedTransaction } from "@solana/web3.js";
import { ObligationType, PoolType, ReserveType } from ".";
import BN from "bn.js";
import JSBI from "jsbi";
import { SaveWallet } from "./actions";
export declare class Margin {
    connection: Connection;
    obligation?: ObligationType;
    wallet: SaveWallet;
    obligationAddress: PublicKey;
    longReserve: ReserveType;
    shortReserve: ReserveType;
    pool: PoolType;
    collateralReserve?: ReserveType;
    longReserveLiquidityAta: PublicKey;
    longReserveCollateralAta: PublicKey;
    shortReserveLiquidityAta: PublicKey;
    shortReserveCollateralAta: PublicKey;
    obligationSeed?: string;
    lendingMarketAuthority: PublicKey;
    depositKeys: Array<PublicKey>;
    borrowKeys: Array<PublicKey>;
    constructor(connection: Connection, wallet: SaveWallet, longReserve: ReserveType, shortReserve: ReserveType, pool: PoolType, obligationAddress: PublicKey, obligationSeed?: string, obligation?: ObligationType, collateralReserve?: ReserveType);
    static calculateMaxUserBorrowPower: (shortReserve: ReserveType, longReserve: ReserveType, exchangeRate?: string, closeMode?: "keepLong" | "keepShort", obligation?: ObligationType) => number;
    calculateMaxUserBorrowPower: (closeMode?: "keepLong" | "keepShort", exchangeRate?: string) => number;
    setupTx: (lookupTableAccount?: AddressLookupTableAccount, depositCollateralConfig?: {
        collateralReserve: ReserveType;
        amount: string;
    }) => Promise<{
        tx: VersionedTransaction | null;
        obligationAddress: PublicKey;
        longTokenAccounts: {
            longTmpAccount: PublicKey;
            longATA: PublicKey;
        };
    }>;
    buildCleanupTx: (longTmpAccount: PublicKey, longATA: PublicKey) => Promise<VersionedTransaction>;
    getSolendAccountCount: () => number;
    leverTx: (swapBaseAmount: BN, route: {
        outAmount: JSBI;
        slippageBps: number;
    }, swapInstructions: Array<TransactionInstruction>, lookupTableAccounts: AddressLookupTableAccount[], longTmpAccount: PublicKey) => Promise<VersionedTransaction>;
}
