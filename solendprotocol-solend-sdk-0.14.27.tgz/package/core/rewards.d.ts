/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import * as anchor from "@coral-xyz/anchor";
import { Connection, PublicKey } from "@solana/web3.js";
export type ClaimData = {
    name: string;
    obligationID: string;
    lotNumber: number;
    index: number;
    quantity: string;
    root: string;
    proof: Array<string>;
    distributorPublicKey: PublicKey;
    optionMarketKey: PublicKey | null;
    incentivizer: string;
};
export type FullClaimDataType = ClaimData & {
    accountFunded: boolean;
    claimId: PublicKey;
    claimStatusBump: number;
    claimed: boolean;
    claimedAt: number;
    distributor: {
        mint: PublicKey;
    };
    distributorATAPublicKey: PublicKey;
};
export declare function fetchClaimData(obligationAddress: PublicKey, connection: Connection): Promise<Array<FullClaimDataType>>;
export declare function getClaimIx(claimData: FullClaimDataType, connection: Connection, publicKey: PublicKey): Promise<anchor.web3.TransactionInstruction>;
