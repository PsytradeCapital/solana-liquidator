"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SolendActionCore = exports.CROSSBAR_URL2 = exports.CROSSBAR_URL1 = exports.transferComputeUnits = exports.createAccountComputeUnits = exports.createAssociatedTokenAccountInstructionComputeUnits = exports.withdrawAndBurnWrapperTokensInstructionComputeUnits = exports.createAssociatedTokenAccountIdempotentInstructionComputeUnits = exports.createDepositAndMintWrapperTokensInstructionComputeUnits = exports.toHexString = void 0;
const web3_js_1 = require("@solana/web3.js");
const spl_token_1 = require("@solana/spl-token");
const bn_js_1 = __importDefault(require("bn.js"));
const bignumber_js_1 = __importDefault(require("bignumber.js"));
const pyth_solana_receiver_1 = require("@pythnetwork/pyth-solana-receiver");
const obligation_1 = require("../state/obligation");
const reserve_1 = require("../state/reserve");
const instructions_1 = require("../instructions");
const constants_1 = require("./constants");
const constants_2 = require("./constants");
const price_service_client_1 = require("@pythnetwork/price-service-client");
const anchor_30_1 = require("@coral-xyz/anchor-30");
const on_demand_1 = require("@switchboard-xyz/on-demand");
const token2022_wrapper_sdk_1 = require("@solendprotocol/token2022-wrapper-sdk");
const SOL_PADDING_FOR_INTEREST = "1000000";
function getSupportRequirementsForAction(action, hasBorrows) {
    const actionSupportRequirements = {
        deposit: ["wsol", "wrap", "createObligation", "cAta"],
        borrow: ["wsol", "ata", "refreshReserves", "refreshObligation", "unwrap"],
        withdraw: [
            "wsol",
            "ata",
            "cAta",
            hasBorrows ? "refreshReserves" : undefined,
            hasBorrows ? "refreshObligation" : undefined,
            "unwrap",
        ].filter((support) => support !== undefined),
        repay: ["wsol", "wrap"],
        mint: ["wsol", "wrap", "cAta"],
        redeem: ["wsol", "ata", hasBorrows ? "refreshReserve" : undefined, "unwrap"].filter((support) => support !== undefined),
        depositCollateral: ["createObligation"],
        withdrawCollateral: ["cAta", hasBorrows ? "refreshReserves" : undefined, hasBorrows ? "refreshObligation" : undefined].filter((support) => support !== undefined),
        forgive: ["refreshReserves", "refreshObligation"],
        liquidate: [
            "wsol",
            "ata",
            "cAta",
            "wrapRepay",
            "unwrap",
            "refreshReserves",
            "refreshObligation",
        ],
    };
    return actionSupportRequirements[action];
}
const toHexString = (byteArray) => {
    return ("0x" +
        Array.from(byteArray, function (byte) {
            return byte.toString(16).padStart(2, "0");
        }).join(""));
};
exports.toHexString = toHexString;
exports.createDepositAndMintWrapperTokensInstructionComputeUnits = 55_154;
exports.createAssociatedTokenAccountIdempotentInstructionComputeUnits = 21_845;
exports.withdrawAndBurnWrapperTokensInstructionComputeUnits = 52_649;
exports.createAssociatedTokenAccountInstructionComputeUnits = 29_490;
exports.createAccountComputeUnits = 10_000;
exports.transferComputeUnits = 500;
exports.CROSSBAR_URL1 = "https://crossbar.save.finance";
exports.CROSSBAR_URL2 = "https://crossbar.switchboard.xyz";
class SolendActionCore {
    programId;
    connection;
    reserve;
    pool;
    publicKey;
    obligationAddress;
    obligationAccountInfo;
    userTokenAccountAddress;
    userCollateralAccountAddress;
    seed;
    positions;
    amount;
    hostAta;
    hostPublicKey;
    // TODO: potentially don't need to keep signers
    pullPriceTxns;
    oracleIxs;
    pythIxGroups;
    setupIxs;
    lendingIxs;
    cleanupIxs;
    preTxnIxs;
    postTxnIxs;
    depositReserves;
    borrowReserves;
    lookupTableAccount;
    wallet;
    debug;
    repayInfo;
    depositInfo;
    token2022Mint;
    wrappedAta;
    environment;
    computeUnitPriceMicroLamports;
    computeUnitLimit;
    errors = [];
    constructor(programId, connection, reserve, pool, wallet, obligationAddress, obligationAccountInfo, userTokenAccountAddress, userCollateralAccountAddress, seed, positions, amount, depositReserves, borrowReserves, config) {
        this.programId = programId;
        this.connection = connection;
        this.publicKey = wallet.publicKey;
        this.amount = new bn_js_1.default(amount);
        this.positions = positions;
        this.hostAta = config?.hostAta;
        this.hostPublicKey = config?.hostPublicKey;
        this.obligationAccountInfo = obligationAccountInfo;
        this.pool = pool;
        this.seed = seed;
        this.reserve = reserve;
        this.obligationAddress = obligationAddress;
        this.userTokenAccountAddress = userTokenAccountAddress;
        this.userCollateralAccountAddress = userCollateralAccountAddress;
        this.pullPriceTxns = [];
        this.pythIxGroups = [];
        this.setupIxs = [];
        this.lendingIxs = [];
        this.cleanupIxs = [];
        this.preTxnIxs = [];
        this.postTxnIxs = [];
        this.oracleIxs = [];
        this.depositReserves = depositReserves;
        this.borrowReserves = borrowReserves;
        this.lookupTableAccount = config?.lookupTableAccount;
        this.depositInfo = config?.depositInfo;
        this.wallet = wallet;
        this.repayInfo = config?.repayInfo;
        this.token2022Mint = config?.token2022Mint;
        this.wrappedAta = config?.wrappedAta;
        // temporarily default to true
        this.debug = config?.debug ?? true;
        this.environment = config?.environment ?? "production";
        this.computeUnitPriceMicroLamports = config?.computeUnitPriceMicroLamports;
        this.computeUnitLimit = config?.computeUnitLimit;
    }
    static async initialize(pool, reserve, action, amount, wallet, connection, config) {
        const seed = config.customObligationSeed ?? pool.address.slice(0, 32);
        const programId = (0, constants_2.getProgramId)(config.environment ?? "production");
        const obligationAddress = config.customObligationAddress ??
            (await web3_js_1.PublicKey.createWithSeed(wallet.publicKey, seed, programId));
        const obligationAccountInfo = await connection.getAccountInfo(obligationAddress, "processed");
        let obligationDetails = null;
        const depositReserves = [];
        const borrowReserves = [];
        if (obligationAccountInfo) {
            obligationDetails = (0, obligation_1.parseObligation)(web3_js_1.PublicKey.default, obligationAccountInfo).info;
            obligationDetails.deposits.forEach((deposit) => {
                depositReserves.push(deposit.depositReserve);
            });
            obligationDetails.borrows.forEach((borrow) => {
                borrowReserves.push(borrow.borrowReserve);
            });
        }
        // Union of addresses
        const distinctReserveCount = Array.from(new Set([
            ...borrowReserves.map((e) => e.toBase58()),
            ...(action === "borrow" ? [reserve.address] : []),
        ])).length +
            Array.from(new Set([
                ...depositReserves.map((e) => e.toBase58()),
                ...(action === "deposit" ? [reserve.address] : []),
            ])).length;
        if (distinctReserveCount > constants_1.POSITION_LIMIT &&
            ["deposit", "borrow"].includes(action)) {
            throw Error(`Obligation already has max number of positions: ${constants_1.POSITION_LIMIT}`);
        }
        const userTokenAccountAddress = await (0, spl_token_1.getAssociatedTokenAddress)(new web3_js_1.PublicKey(reserve.mintAddress), wallet.publicKey, true);
        const userCollateralAccountAddress = await (0, spl_token_1.getAssociatedTokenAddress)(new web3_js_1.PublicKey(reserve.cTokenMint), wallet.publicKey, true);
        const lookupTableAccount = config.lookupTableAddress
            ? (await connection.getAddressLookupTable(config.lookupTableAddress))
                .value
            : undefined;
        const userRepayTokenAccountAddress = config.repayReserve
            ? await (0, spl_token_1.getAssociatedTokenAddress)(new web3_js_1.PublicKey(config.repayReserve.mintAddress), wallet.publicKey, true)
            : undefined;
        const userRepayCollateralAccountAddress = config.repayReserve
            ? await (0, spl_token_1.getAssociatedTokenAddress)(new web3_js_1.PublicKey(config.repayReserve.cTokenMint), wallet.publicKey, true)
            : undefined;
        return new SolendActionCore(programId, connection, reserve, pool, wallet, obligationAddress, obligationDetails, userTokenAccountAddress, userCollateralAccountAddress, seed, distinctReserveCount, amount, depositReserves, borrowReserves, {
            environment: config.environment,
            hostAta: config.hostAta,
            hostPublicKey: config.hostPublicKey,
            lookupTableAccount: lookupTableAccount ?? undefined,
            repayInfo: config.repayReserve
                ? {
                    userRepayTokenAccountAddress: userRepayTokenAccountAddress,
                    userRepayCollateralAccountAddress: userRepayCollateralAccountAddress,
                    repayToken2022Mint: config.repayToken2022Mint
                        ? new web3_js_1.PublicKey(config.repayToken2022Mint)
                        : undefined,
                    repayWrappedAta: config.repayToken2022Mint
                        ? (0, spl_token_1.getAssociatedTokenAddressSync)(new web3_js_1.PublicKey(config.repayToken2022Mint), wallet.publicKey, true, spl_token_1.TOKEN_2022_PROGRAM_ID)
                        : undefined,
                    repayMint: new web3_js_1.PublicKey(config.repayReserve.mintAddress),
                    reserveAddress: new web3_js_1.PublicKey(config.repayReserve.address),
                }
                : undefined,
            token2022Mint: config.token2022Mint
                ? new web3_js_1.PublicKey(config.token2022Mint)
                : undefined,
            wrappedAta: config.token2022Mint
                ? (0, spl_token_1.getAssociatedTokenAddressSync)(new web3_js_1.PublicKey(config.token2022Mint), wallet.publicKey, true, spl_token_1.TOKEN_2022_PROGRAM_ID)
                : undefined,
            depositInfo: config.depositInfo,
            debug: config.debug,
            computeUnitPriceMicroLamports: config.computeUnitPriceMicroLamports,
            computeUnitLimit: config.computeUnitLimit,
        });
    }
    static async buildForgiveTxns(pool, reserve, connection, amount, wallet, obligationAddress, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "deposit", new bn_js_1.default(amount), wallet, connection, {
            ...config,
            customObligationAddress: obligationAddress,
        });
        await axn.addSupportIxs("forgive");
        await axn.addForgiveIx();
        return axn;
    }
    static async buildDepositTxns(pool, reserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "deposit", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("deposit");
        await axn.addDepositIx();
        return axn;
    }
    static async buildBorrowTxns(pool, reserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "borrow", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("borrow");
        await axn.addBorrowIx();
        return axn;
    }
    static async buildDepositReserveLiquidityTxns(pool, reserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "mint", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("mint");
        await axn.addDepositReserveLiquidityIx();
        return axn;
    }
    static async buildRedeemReserveCollateralTxns(pool, reserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "redeem", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("redeem");
        await axn.addRedeemReserveCollateralIx();
        return axn;
    }
    static async buildDepositObligationCollateralTxns(pool, reserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "depositCollateral", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("depositCollateral");
        await axn.addDepositObligationCollateralIx();
        return axn;
    }
    static async buildWithdrawCollateralTxns(pool, reserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "withdrawCollateral", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("withdrawCollateral");
        await axn.addWithdrawObligationCollateralIx();
        return axn;
    }
    static async buildWithdrawTxns(pool, reserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "withdraw", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("withdraw");
        await axn.addWithdrawIx();
        return axn;
    }
    static async buildRepayTxns(pool, reserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, reserve, "repay", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("repay");
        await axn.addRepayIx();
        return axn;
    }
    static async buildLiquidateTxns(pool, withdrawReserve, connection, amount, wallet, config) {
        const axn = await SolendActionCore.initialize(pool, withdrawReserve, "liquidate", new bn_js_1.default(amount), wallet, connection, config);
        await axn.addSupportIxs("liquidate");
        if (!config.repayReserve)
            throw new Error("Repay reserve is required");
        await axn.addLiquidateIx(config.repayReserve);
        return axn;
    }
    // Could fail for obligations with 6 positions and no lookup table
    async getVersionedTransaction() {
        return new web3_js_1.VersionedTransaction(new web3_js_1.TransactionMessage({
            payerKey: this.publicKey,
            recentBlockhash: (await this.connection.getLatestBlockhash()).blockhash,
            instructions: [
                ...this.preTxnIxs.map((ix) => ix.instruction),
                ...this.setupIxs.map((ix) => ix.instruction),
                ...this.lendingIxs.map((ix) => ix.instruction),
                ...this.cleanupIxs.map((ix) => ix.instruction),
                ...this.postTxnIxs.map((ix) => ix.instruction),
            ],
        }).compileToV0Message(this.lookupTableAccount ? [this.lookupTableAccount] : []));
    }
    async getLegacyTransactions() {
        const txns = {
            preLendingTxn: null,
            lendingTxn: null,
            postLendingTxn: null,
        };
        if (this.preTxnIxs.length) {
            txns.preLendingTxn = new web3_js_1.Transaction({
                feePayer: this.publicKey,
                recentBlockhash: (await this.connection.getLatestBlockhash()).blockhash,
            }).add(...this.preTxnIxs.map((ix) => ix.instruction));
        }
        txns.lendingTxn = new web3_js_1.Transaction({
            feePayer: this.publicKey,
            recentBlockhash: (await this.connection.getLatestBlockhash()).blockhash,
        }).add(...this.setupIxs.map((ix) => ix.instruction), ...this.lendingIxs.map((ix) => ix.instruction), ...this.cleanupIxs.map((ix) => ix.instruction));
        if (this.postTxnIxs.length) {
            txns.postLendingTxn = new web3_js_1.Transaction({
                feePayer: this.publicKey,
                recentBlockhash: (await this.connection.getLatestBlockhash()).blockhash,
            }).add(...this.postTxnIxs.map((ix) => ix.instruction));
        }
        return txns;
    }
    async getInstructions() {
        return {
            oracleIxs: this.oracleIxs,
            pythIxGroups: this.pythIxGroups,
            preLendingIxs: this.preTxnIxs,
            lendingIxs: this.setupIxs.concat(this.lendingIxs).concat(this.cleanupIxs),
            postLendingIxs: this.postTxnIxs,
        };
    }
    async getTransactions(blockhash) {
        const txns = {
            preLendingTxn: null,
            lendingTxn: null,
            postLendingTxn: null,
            pullPriceTxns: null,
        };
        const priorityFeeIx = web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
            microLamports: this.computeUnitPriceMicroLamports ?? 500_000,
        });
        const modifyComputeUnits = web3_js_1.ComputeBudgetProgram.setComputeUnitLimit({
            units: this.computeUnitLimit ?? 1_000_000,
        });
        if (this.pullPriceTxns.length) {
            txns.pullPriceTxns = this.pullPriceTxns;
        }
        if (this.preTxnIxs.length) {
            txns.preLendingTxn = new web3_js_1.VersionedTransaction(new web3_js_1.TransactionMessage({
                payerKey: this.publicKey,
                recentBlockhash: blockhash.blockhash,
                instructions: [priorityFeeIx, modifyComputeUnits, ...this.preTxnIxs.map((ix) => ix.instruction)],
            }).compileToV0Message());
        }
        const instructions = [
            ...this.setupIxs,
            ...this.lendingIxs,
            ...this.cleanupIxs,
        ];
        txns.lendingTxn = new web3_js_1.VersionedTransaction(new web3_js_1.TransactionMessage({
            payerKey: this.publicKey,
            recentBlockhash: blockhash.blockhash,
            instructions: [priorityFeeIx, modifyComputeUnits, ...instructions.map((ix) => ix.instruction)],
        }).compileToV0Message(this.lookupTableAccount ? [this.lookupTableAccount] : []));
        if (this.postTxnIxs.length) {
            txns.postLendingTxn = new web3_js_1.VersionedTransaction(new web3_js_1.TransactionMessage({
                payerKey: this.publicKey,
                recentBlockhash: blockhash.blockhash,
                instructions: [priorityFeeIx, modifyComputeUnits, ...this.postTxnIxs.map((ix) => ix.instruction)],
            }).compileToV0Message());
        }
        return txns;
    }
    addForgiveIx() {
        if (this.debug)
            console.log("adding forgive ix to lending txn");
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: (0, instructions_1.forgiveDebtInstruction)(this.obligationAddress, new web3_js_1.PublicKey(this.reserve.address), new web3_js_1.PublicKey(this.pool.address), new web3_js_1.PublicKey(this.pool.owner), this.amount, this.programId),
            computeUnits: -1,
        });
    }
    addDepositIx() {
        if (this.debug)
            console.log("adding deposit ix to lending txn", (this.depositInfo?.userDepositTokenAccountAddress ?? this.userTokenAccountAddress).toString());
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: this.amount.toString() === constants_2.U64_MAX
                ? (0, instructions_1.depositMaxReserveLiquidityAndObligationCollateralInstruction)(this.depositInfo?.userDepositTokenAccountAddress ?? this.userTokenAccountAddress, this.userCollateralAccountAddress, new web3_js_1.PublicKey(this.reserve.address), new web3_js_1.PublicKey(this.reserve.liquidityAddress), new web3_js_1.PublicKey(this.reserve.cTokenMint), new web3_js_1.PublicKey(this.pool.address), new web3_js_1.PublicKey(this.pool.authorityAddress), new web3_js_1.PublicKey(this.reserve.cTokenLiquidityAddress), // destinationCollateral
                this.obligationAddress, // obligation
                this.publicKey, // obligationOwner
                new web3_js_1.PublicKey(this.reserve.pythOracle), new web3_js_1.PublicKey(this.reserve.switchboardOracle), this.publicKey, // transferAuthority
                this.programId)
                : (0, instructions_1.depositReserveLiquidityAndObligationCollateralInstruction)(this.amount, this.depositInfo?.userDepositTokenAccountAddress ?? this.userTokenAccountAddress, this.userCollateralAccountAddress, new web3_js_1.PublicKey(this.reserve.address), new web3_js_1.PublicKey(this.reserve.liquidityAddress), new web3_js_1.PublicKey(this.reserve.cTokenMint), new web3_js_1.PublicKey(this.pool.address), new web3_js_1.PublicKey(this.pool.authorityAddress), new web3_js_1.PublicKey(this.reserve.cTokenLiquidityAddress), // destinationCollateral
                this.obligationAddress, // obligation
                this.publicKey, // obligationOwner
                new web3_js_1.PublicKey(this.reserve.pythOracle), new web3_js_1.PublicKey(this.reserve.switchboardOracle), this.publicKey, // transferAuthority
                this.programId),
            computeUnits: this.amount.toString() === constants_2.U64_MAX ? 102_007 : 83_271
        });
    }
    addDepositReserveLiquidityIx() {
        if (this.debug)
            console.log("adding mint ix to lending txn");
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: (0, instructions_1.depositReserveLiquidityInstruction)(this.amount, this.userTokenAccountAddress, this.userCollateralAccountAddress, new web3_js_1.PublicKey(this.reserve.address), new web3_js_1.PublicKey(this.reserve.liquidityAddress), new web3_js_1.PublicKey(this.reserve.cTokenMint), new web3_js_1.PublicKey(this.pool.address), new web3_js_1.PublicKey(this.pool.authorityAddress), this.publicKey, // transferAuthority
            this.programId),
            computeUnits: 56_142
        });
    }
    addRedeemReserveCollateralIx() {
        if (this.debug)
            console.log("adding redeem ix to lending txn");
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: (0, instructions_1.redeemReserveCollateralInstruction)(this.amount, this.userCollateralAccountAddress, this.userTokenAccountAddress, new web3_js_1.PublicKey(this.reserve.address), new web3_js_1.PublicKey(this.reserve.cTokenMint), new web3_js_1.PublicKey(this.reserve.liquidityAddress), new web3_js_1.PublicKey(this.pool.address), // pool
            new web3_js_1.PublicKey(this.pool.authorityAddress), // poolAuthority
            this.publicKey, // transferAuthority
            this.programId),
            computeUnits: 100_000
        });
    }
    async addWithdrawObligationCollateralIx() {
        if (this.debug)
            console.log("adding withdrawCollateral ix to lending txn");
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: (0, instructions_1.withdrawObligationCollateralInstruction)(this.amount, new web3_js_1.PublicKey(this.reserve.cTokenLiquidityAddress), this.userCollateralAccountAddress, new web3_js_1.PublicKey(this.reserve.address), this.obligationAddress, // obligation
            new web3_js_1.PublicKey(this.pool.address), // pool
            new web3_js_1.PublicKey(this.pool.authorityAddress), // poolAuthority
            this.publicKey, // transferAuthority
            this.programId, this.depositReserves.map((reserve) => new web3_js_1.PublicKey(reserve))),
            computeUnits: 22_932 + (this.positions ?? 0) * 10_000
        });
    }
    addDepositObligationCollateralIx() {
        if (this.debug)
            console.log("adding depositCollateral ix to lending txn");
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: (0, instructions_1.depositObligationCollateralInstruction)(this.amount, this.userCollateralAccountAddress, new web3_js_1.PublicKey(this.reserve.cTokenLiquidityAddress), new web3_js_1.PublicKey(this.reserve.address), this.obligationAddress, // obligation
            new web3_js_1.PublicKey(this.pool.address), this.publicKey, // obligationOwner
            this.publicKey, // transferAuthority
            this.programId),
            computeUnits: 17_944
        });
    }
    async addBorrowIx() {
        if (this.debug)
            console.log("adding borrow ix to lending txn");
        if (this.hostAta && this.hostPublicKey && (this.hostPublicKey.toBase58() !== this.publicKey.toBase58())) {
            this.preTxnIxs.push({
                instruction: (0, spl_token_1.createAssociatedTokenAccountIdempotentInstruction)(this.publicKey, this.hostAta, this.hostPublicKey, new web3_js_1.PublicKey(this.reserve.mintAddress)),
                computeUnits: 21_845
            });
        }
        const liquidityFeeReceiverAccount = await this.connection.getAccountInfo(new web3_js_1.PublicKey(this.reserve.liquidityFeeReceiverAddress));
        if (!liquidityFeeReceiverAccount) {
            this.preTxnIxs.push({
                instruction: (0, spl_token_1.createAssociatedTokenAccountIdempotentInstruction)(this.publicKey, new web3_js_1.PublicKey(this.reserve.liquidityFeeReceiverAddress), constants_1.FEE_RECEIVER_AUTHORITY, new web3_js_1.PublicKey(this.reserve.mintAddress)),
                computeUnits: 21_845
            });
        }
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: (0, instructions_1.borrowObligationLiquidityInstruction)(this.amount, new web3_js_1.PublicKey(this.reserve.liquidityAddress), this.userTokenAccountAddress, new web3_js_1.PublicKey(this.reserve.address), new web3_js_1.PublicKey(this.reserve.liquidityFeeReceiverAddress), this.obligationAddress, new web3_js_1.PublicKey(this.pool.address), // lendingMarket
            new web3_js_1.PublicKey(this.pool.authorityAddress), // lendingMarketAuthority
            this.publicKey, this.programId, this.depositReserves.map((reserve) => new web3_js_1.PublicKey(reserve)), this.hostAta),
            computeUnits: 87_660 + ((this.positions ?? 0) * 10_000)
        });
    }
    async addWithdrawIx() {
        if (this.debug)
            console.log("adding withdraw ix to lending txn");
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: this.amount.eq(new bn_js_1.default(constants_2.U64_MAX))
                ? (0, instructions_1.withdrawObligationCollateralAndRedeemReserveLiquidity)(new bn_js_1.default(constants_2.U64_MAX), new web3_js_1.PublicKey(this.reserve.cTokenLiquidityAddress), this.userCollateralAccountAddress, new web3_js_1.PublicKey(this.reserve.address), this.obligationAddress, new web3_js_1.PublicKey(this.pool.address), new web3_js_1.PublicKey(this.pool.authorityAddress), this.userTokenAccountAddress, // destinationLiquidity
                new web3_js_1.PublicKey(this.reserve.cTokenMint), new web3_js_1.PublicKey(this.reserve.liquidityAddress), this.publicKey, // obligationOwner
                this.publicKey, // transferAuthority
                this.programId, this.depositReserves.map((reserve) => new web3_js_1.PublicKey(reserve)))
                : (0, instructions_1.withdrawExact)(this.amount, new web3_js_1.PublicKey(this.reserve.cTokenLiquidityAddress), this.userCollateralAccountAddress, new web3_js_1.PublicKey(this.reserve.address), new web3_js_1.PublicKey(this.userTokenAccountAddress), new web3_js_1.PublicKey(this.reserve.cTokenMint), new web3_js_1.PublicKey(this.reserve.liquidityAddress), new web3_js_1.PublicKey(this.obligationAddress), new web3_js_1.PublicKey(this.pool.address), new web3_js_1.PublicKey(this.pool.authorityAddress), new web3_js_1.PublicKey(this.publicKey), new web3_js_1.PublicKey(this.publicKey), this.programId, this.depositReserves.map((reserve) => new web3_js_1.PublicKey(reserve))),
            computeUnits: this.amount.eq(new bn_js_1.default(constants_2.U64_MAX)) ? (85_000 + ((this.positions ?? 0) * 10_000)) : 116_479 + ((this.positions ?? 0) * 10_000)
        });
    }
    async addRepayIx() {
        if (this.debug)
            console.log("adding repay ix to lending txn");
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: this.amount.toString() === constants_2.U64_MAX
                ? (0, instructions_1.repayMaxObligationLiquidityInstruction)(this.userTokenAccountAddress, new web3_js_1.PublicKey(this.reserve.liquidityAddress), new web3_js_1.PublicKey(this.reserve.address), this.obligationAddress, new web3_js_1.PublicKey(this.pool.address), this.publicKey, this.programId)
                : (0, instructions_1.repayObligationLiquidityInstruction)(this.amount, this.userTokenAccountAddress, new web3_js_1.PublicKey(this.reserve.liquidityAddress), new web3_js_1.PublicKey(this.reserve.address), this.obligationAddress, new web3_js_1.PublicKey(this.pool.address), this.publicKey, this.programId),
            computeUnits: 63549,
        });
    }
    async addLiquidateIx(repayReserve) {
        if (this.debug)
            console.log("adding liquidate ix to lending txn");
        if (!this.repayInfo?.userRepayCollateralAccountAddress ||
            !this.repayInfo?.userRepayTokenAccountAddress) {
            throw Error("Not correctly initialized with a withdraw reserve.");
        }
        this.lendingIxs.push({
            lookupTableAccounts: this.lookupTableAccount ? [this.lookupTableAccount] : undefined,
            instruction: (0, instructions_1.liquidateObligationAndRedeemReserveCollateral)(this.amount, this.repayInfo.userRepayTokenAccountAddress, this.userCollateralAccountAddress, this.userTokenAccountAddress, new web3_js_1.PublicKey(repayReserve.address), new web3_js_1.PublicKey(repayReserve.liquidityAddress), new web3_js_1.PublicKey(this.reserve.address), new web3_js_1.PublicKey(this.reserve.cTokenMint), new web3_js_1.PublicKey(this.reserve.cTokenLiquidityAddress), new web3_js_1.PublicKey(this.reserve.liquidityAddress), new web3_js_1.PublicKey(this.reserve.liquidityFeeReceiverAddress), this.obligationAddress, new web3_js_1.PublicKey(this.pool.address), new web3_js_1.PublicKey(this.pool.authorityAddress), this.publicKey, this.programId),
            computeUnits: 80_000 + ((this.positions ?? 0) * 2_500)
        });
    }
    async addSupportIxs(action) {
        const supports = getSupportRequirementsForAction(action, this.borrowReserves.length > 0);
        for (const support of supports) {
            switch (support) {
                case "createObligation":
                    await this.addObligationIxs();
                    break;
                case "wrap":
                    if (this.wrappedAta) {
                        await this.addWrapIx();
                    }
                    break;
                case "unwrap":
                    if (this.wrappedAta) {
                        await this.addUnwrapIx();
                    }
                    break;
                case "refreshReserve":
                    await this.addRefreshReservesIxs(true);
                    break;
                case "refreshReserves":
                    await this.addRefreshReservesIxs();
                    break;
                case "refreshObligation":
                    await this.addRefreshObligationIxs();
                    break;
                case "cAta":
                    await this.addCAtaIxs();
                    break;
                case "ata":
                    await this.addAtaIxs();
                    break;
                case "wrapRepay":
                    if (this.repayInfo?.repayWrappedAta) {
                        await this.addWrapRepayIx();
                    }
                    break;
                case "wsol":
                    await this.updateWSOLAccount(action);
                    break;
            }
        }
    }
    async addWrapIx() {
        if (!this.wrappedAta || !this.token2022Mint)
            throw new Error("Wrapped ATA not initialized");
        if (this.debug)
            console.log("adding wrap ix to preTxnIxs");
        this.preTxnIxs.push({
            instruction: (0, spl_token_1.createAssociatedTokenAccountIdempotentInstruction)(this.publicKey, this.userTokenAccountAddress, this.publicKey, new web3_js_1.PublicKey(this.reserve.mintAddress)),
            computeUnits: exports.createAssociatedTokenAccountIdempotentInstructionComputeUnits
        });
        this.preTxnIxs.push({
            instruction: await (0, token2022_wrapper_sdk_1.createDepositAndMintWrapperTokensInstruction)(this.publicKey, this.wrappedAta, this.token2022Mint, this.amount),
            computeUnits: exports.createDepositAndMintWrapperTokensInstructionComputeUnits
        });
    }
    async addUnwrapIx() {
        if (!this.wrappedAta || !this.token2022Mint)
            throw new Error("Wrapped ATA not initialized");
        if (this.debug)
            console.log("adding wrap ix to preTxnIxs");
        this.preTxnIxs.push({
            instruction: (0, spl_token_1.createAssociatedTokenAccountIdempotentInstruction)(this.publicKey, this.wrappedAta, this.publicKey, this.token2022Mint, spl_token_1.TOKEN_2022_PROGRAM_ID),
            computeUnits: exports.createAssociatedTokenAccountIdempotentInstructionComputeUnits
        });
        if (this.debug)
            console.log("adding wrap ix to postTxnIxs");
        this.postTxnIxs.push({
            instruction: await (0, token2022_wrapper_sdk_1.createWithdrawAndBurnWrapperTokensInstruction)(this.publicKey, this.wrappedAta, this.token2022Mint, new bn_js_1.default(constants_2.U64_MAX)),
            computeUnits: exports.withdrawAndBurnWrapperTokensInstructionComputeUnits
        });
    }
    async addWrapRepayIx() {
        if (!this.repayInfo?.repayWrappedAta || !this.repayInfo?.repayToken2022Mint)
            throw new Error("Wrapped ATA not initialized");
        this.preTxnIxs.push({
            instruction: (0, spl_token_1.createAssociatedTokenAccountIdempotentInstruction)(this.publicKey, this.repayInfo.userRepayTokenAccountAddress, this.publicKey, new web3_js_1.PublicKey(this.repayInfo.repayMint)),
            computeUnits: 21_845
        });
        this.preTxnIxs.push({
            instruction: await (0, token2022_wrapper_sdk_1.createDepositAndMintWrapperTokensInstruction)(this.publicKey, this.repayInfo.repayWrappedAta, this.repayInfo.repayToken2022Mint, this.amount),
            computeUnits: 55_154
        });
    }
    static async buildPullPriceIxsStatic(unfilteredOracleKeys, connection, wallet, computeUnitPriceMicroLamports, environment, debug) {
        const oracleKeys = unfilteredOracleKeys.filter(k => k !== 'nu11111111111111111111111111111111111111111' && k !== '11111111111111111111111111111111');
        let oracleIxs = [];
        let pullPriceTxns = [];
        let pythIxGroups = [];
        const priorityFeeIx = web3_js_1.ComputeBudgetProgram.setComputeUnitPrice({
            microLamports: computeUnitPriceMicroLamports ?? 1_000_000,
        });
        const modifyComputeUnits = web3_js_1.ComputeBudgetProgram.setComputeUnitLimit({
            units: 1_000_000,
        });
        const oracleAccounts = (await connection.getMultipleAccountsInfo(oracleKeys.map((o) => new web3_js_1.PublicKey(o)), "processed"));
        const provider = new anchor_30_1.AnchorProvider(connection, {
            publicKey: wallet.publicKey,
            signTransaction: (tx) => Promise.resolve(tx),
            signAllTransactions: (txs) => Promise.resolve(txs),
        }, {});
        const idl = (await anchor_30_1.Program.fetchIdl(on_demand_1.ON_DEMAND_MAINNET_PID, provider));
        if (environment === "production" || environment === "beta") {
            const sbod = new anchor_30_1.Program(idl, provider);
            const sbPulledOracles = oracleKeys.filter((_o, index) => oracleAccounts[index]?.owner.toBase58() === sbod.programId.toBase58());
            if (sbPulledOracles.length) {
                const feedAccounts = await Promise.all(sbPulledOracles.map((oracleKey) => new on_demand_1.PullFeed(sbod, oracleKey)));
                if (debug)
                    console.log("Feed accounts", sbPulledOracles);
                const loadedFeedAccounts = await Promise.all(feedAccounts.map((acc) => acc.loadData()));
                const numSignatures = Math.max(...loadedFeedAccounts.map((f) => f.minSampleSize + Math.ceil(f.minSampleSize / 3)), 1);
                const res = feedAccounts.reduce((acc, _curr, i) => {
                    if (!(i % 3)) {
                        // if index is 0 or can be divided by the `size`...
                        acc.push(feedAccounts.slice(i, i + 3)); // ..push a chunk of the original array to the accumulator
                    }
                    return acc;
                }, []);
                const signatureInstructionIdxRaw = typeof localStorage !== "undefined"
                    ? localStorage.getItem("signatureInstructionIdx")
                    : null;
                const signatureInstructionIdx = signatureInstructionIdxRaw
                    ? parseInt(signatureInstructionIdxRaw)
                    : undefined;
                await Promise.all(res.map(async (feedAccountGroup, groupIndex) => {
                    const gateway = await feedAccountGroup[0].fetchGatewayUrl();
                    const [ix, accountLookups] = await on_demand_1.PullFeed.fetchUpdateManyIx(sbod, {
                        chain: "solana",
                        network: "mainnet-beta",
                        feeds: feedAccountGroup,
                        numSignatures,
                        gateway,
                        signatureInstructionIdx,
                    });
                    const lookupTables = (await (0, on_demand_1.loadLookupTables)(feedAccounts)).concat(accountLookups);
                    const instructions = [priorityFeeIx, modifyComputeUnits, ...ix];
                    const { value: { blockhash }, } = await connection.getLatestBlockhashAndContext();
                    const message = new web3_js_1.TransactionMessage({
                        payerKey: wallet.publicKey,
                        recentBlockhash: blockhash,
                        instructions,
                    }).compileToV0Message(lookupTables);
                    const vtx = new web3_js_1.VersionedTransaction(message);
                    if (debug)
                        console.log("adding sbod ix to pullPriceTxns");
                    ix.forEach((ixn, index) => {
                        oracleIxs.push({
                            instruction: ixn,
                            lookupTableAccounts: lookupTables,
                            computeUnits: index === 0 ? 400_000 + sbPulledOracles.length * 100_000 : 10_000,
                            groupIndex,
                            index0: true
                        });
                    });
                    pullPriceTxns.push(vtx);
                }));
            }
        }
        const priceServiceConnection = new price_service_client_1.PriceServiceConnection("https://hermes.pyth.network");
        const pythSolanaReceiver = new pyth_solana_receiver_1.PythSolanaReceiver({
            connection: connection,
            wallet: wallet,
        });
        const transactionBuilder = pythSolanaReceiver.newTransactionBuilder({
            closeUpdateAccounts: true,
        });
        const pythPulledOracles = oracleAccounts.filter((o) => o?.owner.toBase58() === pythSolanaReceiver.receiver.programId.toBase58());
        const shuffledPriceIds = pythPulledOracles
            .map((pythOracleData, index) => {
            if (!pythOracleData) {
                throw new Error(`Could not find oracle data at index ${index}`);
            }
            const priceUpdate = pythSolanaReceiver.receiver.account.priceUpdateV2.coder.accounts.decode("priceUpdateV2", pythOracleData.data);
            const needUpdate = Date.now() / 1000 -
                Number(priceUpdate.priceMessage.publishTime.toString()) >
                80;
            return needUpdate
                ? {
                    key: Math.random(),
                    priceFeedId: (0, exports.toHexString)(priceUpdate.priceMessage.feedId),
                }
                : undefined;
        })
            .filter(Boolean)
            .sort((a, b) => a.key - b.key)
            .map((x) => x.priceFeedId);
        if (shuffledPriceIds.length) {
            if (debug)
                console.log("Feed accounts", shuffledPriceIds);
            const priceFeedUpdateData = await priceServiceConnection.getLatestVaas(shuffledPriceIds);
            await transactionBuilder.addUpdatePriceFeed(priceFeedUpdateData, 0 // shardId of 0
            );
            const transactionsWithSigners = await transactionBuilder.buildVersionedTransactions({});
            for (const [index, transaction] of transactionsWithSigners.entries()) {
                const signers = transaction.signers;
                const tx = transaction.tx;
                const lookupTables = await Promise.all(tx.message.addressTableLookups.map((lookup) => connection.getAddressLookupTable(lookup.accountKey)));
                if (signers) {
                    tx.sign(signers);
                }
                pythIxGroups.push(transactionBuilder.transactionInstructions[index].instructions.map((ix, index2) => {
                    let computeUnits = 0;
                    if (index2 === 0) {
                        computeUnits = 355_787;
                    }
                    if (ix.programId.toBase58() === 'pythWSnswVUd12oZpeFP8e9CVaEqJg25g1Vtc2biRsT') {
                        computeUnits = 43825;
                    }
                    return ({
                        instruction: ix,
                        signers: transactionBuilder.transactionInstructions[index].signers,
                        lookupTables: lookupTables,
                        computeUnits,
                    });
                }));
                pullPriceTxns.push(tx);
            }
            console.log(`adding ${transactionsWithSigners.length} txns to pullPriceTxns`);
        }
        return {
            oracleIxs,
            pythIxGroups,
            pullPriceTxns,
        };
    }
    async buildPullPriceTxns(oracleKeys) {
        const { oracleIxs, pythIxGroups, pullPriceTxns } = await SolendActionCore.buildPullPriceIxsStatic(oracleKeys, this.connection, this.wallet, this.computeUnitPriceMicroLamports ?? 1_000_000, this.environment, this.debug);
        this.oracleIxs.push(...oracleIxs);
        this.pythIxGroups.push(...pythIxGroups);
        this.pullPriceTxns.push(...pullPriceTxns);
    }
    async addRefreshReservesIxs(singleReserve) {
        // Union of addresses
        const reserveMap = this.pool.reserves.reduce((acc, reserve) => {
            acc[reserve.address] = reserve;
            return acc;
        }, {});
        const allReserveAddresses = Array.from(new Set(singleReserve ? [this.reserve.address] : [
            ...this.depositReserves.map((e) => e.toBase58()),
            ...this.borrowReserves.map((e) => e.toBase58()),
            this.reserve.address,
        ]));
        await this.buildPullPriceTxns([
            ...allReserveAddresses.map((address) => reserveMap[address].pythOracle),
            ...allReserveAddresses.map((address) => reserveMap[address].switchboardOracle),
            ...allReserveAddresses.map((address) => reserveMap[address].extraOracle ?? constants_1.NULL_ORACLE.toBase58()),
        ]);
        allReserveAddresses.forEach((reserveAddress) => {
            const reserveInfo = this.pool.reserves.find((reserve) => reserve.address === reserveAddress);
            if (!reserveInfo) {
                throw new Error(`Could not find asset ${reserveAddress} in reserves`);
            }
            if (this.debug)
                console.log(`adding refresh ${reserveAddress} ix to setup txn`);
            const refreshReserveIx = (0, instructions_1.refreshReserveInstruction)(new web3_js_1.PublicKey(reserveAddress), this.programId, new web3_js_1.PublicKey(reserveInfo.pythOracle), new web3_js_1.PublicKey(reserveInfo.switchboardOracle), reserveInfo.extraOracle
                ? new web3_js_1.PublicKey(reserveInfo.extraOracle)
                : undefined);
            this.setupIxs.push({
                instruction: refreshReserveIx,
                computeUnits: 54_690, // 54690 is max amount from a sample. TODO: can get more granular based on pyth/sb/extra oracle
            });
        });
    }
    async addRefreshObligationIxs() {
        const refreshObligationIx = (0, instructions_1.refreshObligationInstruction)(this.obligationAddress, this.depositReserves, this.borrowReserves, this.programId);
        this.depositReserves = this.depositReserves.filter((reserve) => {
            const deposit = this.obligationAccountInfo?.deposits.find((d) => d.depositReserve.toBase58() === reserve.toBase58());
            return deposit?.depositedAmount.gt(new bn_js_1.default(0));
        });
        this.borrowReserves = this.borrowReserves.filter((reserve) => {
            const borrow = this.obligationAccountInfo?.borrows.find((b) => b.borrowReserve.toBase58() === reserve.toBase58());
            return borrow?.borrowedAmountWads.gt(new bn_js_1.default(0));
        });
        if (this.debug)
            console.log("adding refresh obligation ix to setup txn");
        this.setupIxs.push({
            instruction: refreshObligationIx,
            computeUnits: 30_000 * (this.positions ?? 0),
        });
    }
    async addObligationIxs() {
        if (this.debug)
            console.log("addObligationIxs");
        if (!this.obligationAccountInfo) {
            const obligationAccountInfoRentExempt = await this.connection.getMinimumBalanceForRentExemption(obligation_1.OBLIGATION_SIZE);
            if (this.debug)
                console.log("adding createAccount and initObligation ix to setup txn");
            this.setupIxs.push({
                instruction: web3_js_1.SystemProgram.createAccountWithSeed({
                    fromPubkey: this.publicKey,
                    newAccountPubkey: this.obligationAddress,
                    basePubkey: this.publicKey,
                    seed: this.seed,
                    lamports: obligationAccountInfoRentExempt,
                    space: obligation_1.OBLIGATION_SIZE,
                    programId: this.programId,
                }),
                computeUnits: exports.createAccountComputeUnits,
            });
            const initObligationIx = (0, instructions_1.initObligationInstruction)(this.obligationAddress, new web3_js_1.PublicKey(this.pool.address), this.publicKey, this.programId);
            this.setupIxs.push({
                instruction: initObligationIx,
                computeUnits: 4_701
            });
        }
    }
    async addAtaIxs() {
        if (this.reserve.mintAddress !== spl_token_1.NATIVE_MINT.toBase58()) {
            const userTokenAccountInfo = await this.connection.getAccountInfo(this.userTokenAccountAddress);
            if (!userTokenAccountInfo) {
                const createUserTokenAccountIx = {
                    computeUnits: exports.createAssociatedTokenAccountInstructionComputeUnits,
                    instruction: (0, spl_token_1.createAssociatedTokenAccountInstruction)(this.publicKey, this.userTokenAccountAddress, this.publicKey, new web3_js_1.PublicKey(this.reserve.mintAddress))
                };
                if (this.positions === constants_1.POSITION_LIMIT &&
                    this.hostAta &&
                    !this.lookupTableAccount) {
                    if (this.debug)
                        console.log("adding createAta ix to pre txn");
                    this.preTxnIxs.push(createUserTokenAccountIx);
                }
                else {
                    if (this.debug)
                        console.log("adding createAta ix to setup txn");
                    this.setupIxs.push(createUserTokenAccountIx);
                }
            }
        }
    }
    async addCAtaIxs() {
        const userCollateralAccountInfo = await this.connection.getAccountInfo(this.userCollateralAccountAddress);
        if (!userCollateralAccountInfo) {
            const createUserCollateralAccountIx = (0, spl_token_1.createAssociatedTokenAccountInstruction)(this.publicKey, this.userCollateralAccountAddress, this.publicKey, new web3_js_1.PublicKey(this.reserve.cTokenMint));
            if (this.positions === constants_1.POSITION_LIMIT &&
                this.hostAta &&
                !this.lookupTableAccount) {
                if (this.debug)
                    console.log("adding createCAta ix to pre txn");
                this.preTxnIxs.push({
                    instruction: createUserCollateralAccountIx,
                    computeUnits: exports.createAssociatedTokenAccountInstructionComputeUnits
                });
            }
            else {
                if (this.debug)
                    console.log("adding createCAta ix to setup txn");
                this.setupIxs.push({
                    instruction: createUserCollateralAccountIx,
                    computeUnits: exports.createAssociatedTokenAccountInstructionComputeUnits
                });
            }
        }
    }
    async updateWSOLAccount(action) {
        if (![
            this.reserve.mintAddress,
            this.repayInfo?.repayMint.toString(),
        ].includes(spl_token_1.NATIVE_MINT.toBase58()))
            return;
        const preIxs = [];
        const postIxs = [];
        let safeRepay = new bn_js_1.default(this.amount);
        const liquidateWithSol = action === "liquidate" &&
            this.repayInfo?.repayMint.toString() === spl_token_1.NATIVE_MINT.toBase58();
        const solAccountAddress = liquidateWithSol
            ? this.repayInfo.userRepayTokenAccountAddress
            : this.userTokenAccountAddress;
        const borrowReserveAddress = liquidateWithSol
            ? this.repayInfo.reserveAddress.toBase58()
            : this.reserve.address;
        if (this.obligationAccountInfo &&
            (action === "repay" || liquidateWithSol) &&
            this.amount.eq(new bn_js_1.default(constants_2.U64_MAX))) {
            const buffer = await this.connection.getAccountInfo(new web3_js_1.PublicKey(borrowReserveAddress), "processed");
            if (!buffer) {
                throw Error(`Unable to fetch reserve data for ${borrowReserveAddress}`);
            }
            const parsedData = (0, reserve_1.parseReserve)(new web3_js_1.PublicKey(borrowReserveAddress), buffer)?.info;
            if (!parsedData) {
                throw Error(`Unable to parse data of reserve ${borrowReserveAddress}`);
            }
            const borrow = this.obligationAccountInfo.borrows.find((borrow) => borrow.borrowReserve.toBase58() === borrowReserveAddress);
            if (!borrow) {
                throw Error(`Unable to find obligation borrow to repay for ${this.obligationAccountInfo.owner.toBase58()}`);
            }
            safeRepay = new bn_js_1.default(Math.floor(new bignumber_js_1.default(borrow.borrowedAmountWads.toString())
                .multipliedBy(parsedData.liquidity.cumulativeBorrowRateWads.toString())
                .dividedBy(borrow.cumulativeBorrowRateWads.toString())
                .dividedBy(constants_2.WAD)
                .plus(SOL_PADDING_FOR_INTEREST)
                .toNumber()).toString());
        }
        const userWSOLAccountInfo = await this.connection.getAccountInfo(solAccountAddress);
        const rentExempt = await (0, spl_token_1.getMinimumBalanceForRentExemptAccount)(this.connection);
        const sendAction = action === "deposit" ||
            action === "repay" ||
            action === "mint" ||
            liquidateWithSol;
        const transferLamportsIx = web3_js_1.SystemProgram.transfer({
            fromPubkey: this.publicKey,
            toPubkey: solAccountAddress,
            lamports: (userWSOLAccountInfo ? 0 : rentExempt) +
                (sendAction ? parseInt(safeRepay.toString(), 10) : 0),
        });
        if (this.debug)
            console.log("adding transferLamports ix");
        preIxs.push({
            instruction: transferLamportsIx,
            computeUnits: 6_200
        });
        const closeWSOLAccountIx = (0, spl_token_1.createCloseAccountInstruction)(solAccountAddress, this.publicKey, this.publicKey, []);
        if (userWSOLAccountInfo) {
            const syncIx = (0, instructions_1.syncNative)(solAccountAddress);
            if (sendAction) {
                if (this.debug)
                    console.log("adding syncIx ix");
                preIxs.push({
                    instruction: syncIx,
                    computeUnits: 3_045
                });
            }
            else {
                if (this.debug)
                    console.log("adding closeWSOLAccountIx ix");
                postIxs.push({
                    instruction: closeWSOLAccountIx,
                    computeUnits: 3033
                });
            }
        }
        else {
            const createUserWSOLAccountIx = (0, spl_token_1.createAssociatedTokenAccountInstruction)(this.publicKey, solAccountAddress, this.publicKey, spl_token_1.NATIVE_MINT);
            if (this.debug)
                console.log("adding createUserWSOLAccountIx ix");
            preIxs.push({
                instruction: createUserWSOLAccountIx,
                computeUnits: exports.createAssociatedTokenAccountInstructionComputeUnits
            });
            if (this.debug)
                console.log("adding closeWSOLAccountIx ix");
            postIxs.push({
                instruction: closeWSOLAccountIx,
                computeUnits: 3033
            });
        }
        if (this.positions === constants_1.POSITION_LIMIT &&
            this.hostAta &&
            !this.lookupTableAccount) {
            if (this.debug)
                console.log("adding above ixs to pre and post txn");
            this.preTxnIxs.push(...preIxs);
            this.postTxnIxs.push(...postIxs);
        }
        else {
            if (this.debug)
                console.log("adding above ixs to lending txn");
            this.setupIxs.push(...preIxs);
            this.cleanupIxs.push(...postIxs);
        }
    }
}
exports.SolendActionCore = SolendActionCore;
