"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getClaimIx = exports.fetchClaimData = void 0;
const anchor = __importStar(require("@coral-xyz/anchor"));
const spl_token_1 = require("@solana/spl-token");
const web3_js_1 = require("@solana/web3.js");
const merkle_distributor_1 = require("./utils/merkle_distributor");
const nodewallet_1 = __importDefault(require("@coral-xyz/anchor/dist/cjs/nodewallet"));
const axios_1 = __importDefault(require("axios"));
const constants_1 = require("./constants");
const toBytes32Array = (b) => {
    const buf = Buffer.alloc(32);
    b.copy(buf, 32 - b.length);
    return Array.from(buf);
};
async function fetchClaimData(obligationAddress, connection) {
    const claims = (await axios_1.default.get(`https://api.save.finance/liquidity-mining/reward-proofs?obligation=${obligationAddress.toBase58()}`)).data;
    const provider = new anchor.AnchorProvider(connection, new nodewallet_1.default(web3_js_1.Keypair.fromSeed(new Uint8Array(32).fill(1))), {});
    const anchorProgram = new anchor.Program(merkle_distributor_1.MerkleDistributorJSON, new web3_js_1.PublicKey(merkle_distributor_1.MERKLE_PROGRAM_ID), provider);
    const merkleDistributors = (await anchorProgram.account.merkleDistributor.fetchMultiple(claims.map((d) => new web3_js_1.PublicKey(d.distributorPublicKey))));
    const claimAndBumps = await Promise.all(claims.map(async (d) => {
        const claimAndBump = await web3_js_1.PublicKey.findProgramAddress([
            anchor.utils.bytes.utf8.encode("ClaimStatus"),
            new anchor.BN(d.index).toArrayLike(Buffer, "le", 8),
            new web3_js_1.PublicKey(d.distributorPublicKey).toBytes(),
        ], new web3_js_1.PublicKey(merkle_distributor_1.MERKLE_PROGRAM_ID));
        return claimAndBump;
    }));
    const claimStatuses = (await anchorProgram.account.claimStatus.fetchMultiple(claimAndBumps.map((candb) => candb[0])));
    return await Promise.all(claims.map(async (d, index) => {
        const [distributorATAPublicKey, _bump] = merkleDistributors[index] ? await web3_js_1.PublicKey.findProgramAddress([
            new web3_js_1.PublicKey(d.distributorPublicKey).toBuffer(),
            spl_token_1.TOKEN_PROGRAM_ID.toBuffer(),
            merkleDistributors[index].mint.toBuffer(),
        ], spl_token_1.ASSOCIATED_TOKEN_PROGRAM_ID) : [null, null];
        const accountFunded = distributorATAPublicKey
            ? (await anchorProgram.provider.connection.getTokenAccountBalance(distributorATAPublicKey)).value.amount !== "0"
            : true;
        return {
            ...d,
            accountFunded,
            claimId: claimAndBumps[index][0],
            claimStatusBump: claimAndBumps[index][1],
            claimed: merkleDistributors[index]
                ? Boolean(claimStatuses[index]?.isClaimed)
                : true,
            claimedAt: claimStatuses[index]?.claimedAt,
            distributor: merkleDistributors[index] ?? null,
            distributorATAPublicKey: distributorATAPublicKey ?? constants_1.NULL_ORACLE,
        };
    }));
}
exports.fetchClaimData = fetchClaimData;
async function getClaimIx(claimData, connection, publicKey) {
    const provider = new anchor.AnchorProvider(connection, new nodewallet_1.default(web3_js_1.Keypair.fromSeed(new Uint8Array(32).fill(1))), {});
    const anchorProgram = new anchor.Program(merkle_distributor_1.MerkleDistributorJSON, new web3_js_1.PublicKey(merkle_distributor_1.MERKLE_PROGRAM_ID), provider);
    const claimantTokenAccountAddress = await (0, spl_token_1.getAssociatedTokenAddress)(claimData.distributor.mint, publicKey, true);
    return anchorProgram.instruction.claim(claimData.claimStatusBump, new anchor.BN(claimData.index), new anchor.BN(claimData.quantity), claimData.proof.map((p) => toBytes32Array(Buffer.from(p, "hex"))), {
        accounts: {
            distributor: claimData.distributorPublicKey,
            claimStatus: claimData.claimId,
            from: claimData.distributorATAPublicKey,
            to: claimantTokenAccountAddress,
            claimant: publicKey,
            payer: publicKey,
            systemProgram: web3_js_1.SystemProgram.programId,
            tokenProgram: spl_token_1.TOKEN_PROGRAM_ID,
        },
    });
}
exports.getClaimIx = getClaimIx;
