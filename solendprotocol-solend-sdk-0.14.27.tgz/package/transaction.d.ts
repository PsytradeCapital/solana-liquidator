/// <reference types="jito-ts/node_modules/@solana/web3.js" />
import { PublicKey, Signer, TransactionInstruction } from "@solana/web3.js";
/**
 * If the transaction doesn't contain a `setComputeUnitLimit` instruction, the default compute budget is 200,000 units per instruction.
 */
export declare const DEFAULT_COMPUTE_BUDGET_UNITS = 200000;
/**
 * The maximum size of a Solana transaction, leaving some room for the compute budget instructions.
 */
export declare const PACKET_DATA_SIZE_WITH_ROOM_FOR_COMPUTE_BUDGET: number;
/**
 * An instruction with some extra information that will be used to build transactions.
 */
export type InstructionWithEphemeralSigners = {
    /** The instruction */
    instruction: TransactionInstruction;
    /** The ephemeral signers that need to sign the transaction where this instruction will be */
    signers: Signer[];
    /** The compute units that this instruction requires, useful if greater than `DEFAULT_COMPUTE_BUDGET_UNITS`  */
    computeUnits?: number;
};
/**
 * The priority fee configuration for transactions
 */
export type PriorityFeeConfig = {
    /** This is the priority fee in micro lamports, it gets passed down to `setComputeUnitPrice`  */
    computeUnitPriceMicroLamports?: number;
    tightComputeBudget?: boolean;
    jitoTipLamports?: number;
    jitoBundleSize?: number;
};
/**
 * A default priority fee configuration. Using a priority fee is helpful even when you're not writing to hot accounts.
 */
export declare const DEFAULT_PRIORITY_FEE_CONFIG: PriorityFeeConfig;
/**
 * Get the size of a transaction that would contain the provided array of instructions
 * This is based on {@link https://solana.com/docs/core/transactions}.
 *
 * Each transaction has the following layout :
 *
 * - A compact array of all signatures
 * - A 3-bytes message header
 * - A compact array with all the account addresses
 * - A recent blockhash
 * - A compact array of instructions
 *
 * If the transaction is a `VersionedTransaction`, it also contains an extra byte at the beginning, indicating the version and an array of `MessageAddressTableLookup` at the end.
 * After this field there is an array of indexes into the address lookup table that represents the accounts from the address lookup table used in the transaction.
 *
 * Each instruction has the following layout :
 * - One byte indicating the index of the program in the account addresses array
 * - A compact array of indices into the account addresses array, indicating which accounts are used by the instruction
 * - A compact array of serialized instruction data
 */
export declare function getSizeOfTransaction(instructions: TransactionInstruction[], versionedTransaction?: boolean, addressLookupTableAddresses?: PublicKey[]): number;
/**
 * Get the size of n in bytes when serialized as a CompressedU16. Compact arrays use a CompactU16 to store the length of the array.
 */
export declare function getSizeOfCompressedU16(n: number): number;
