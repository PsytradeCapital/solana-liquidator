"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CachedConnection = exports.InMemoryCache = void 0;
class InMemoryCache {
    expireMS;
    maxCacheSize;
    data;
    constructor(expireMS, maxCacheSize = null) {
        this.expireMS = expireMS;
        this.maxCacheSize = maxCacheSize;
        this.data = {};
    }
    async get(key) {
        const cachedObject = this.data[key];
        if (cachedObject === undefined || cachedObject === null) {
            return null;
        }
        const msElapsed = Date.now() - cachedObject.timestamp;
        if (msElapsed > this.expireMS) {
            this.data[key] = null;
            return null;
        }
        return cachedObject.value;
    }
    async set(key, valuePromise) {
        const value = await valuePromise;
        this.data[key] = {
            timestamp: Date.now(),
            value: value,
        };
        // We don't want to let the cache get infinitely big
        // so we just discard the oldest item
        if (this.maxCacheSize !== null &&
            Object.keys(this.data).length === this.maxCacheSize) {
            delete this.data[Object.keys(this.data)[0]];
        }
        return value;
    }
}
exports.InMemoryCache = InMemoryCache;
// Wraps a cache around a connection. You can define a custom cache by
// implementing the RPCCache interface
class CachedConnection {
    connection;
    cache;
    rpcEndpoint;
    constructor(connection, cache) {
        this.connection = connection;
        this.rpcEndpoint = this.connection.rpcEndpoint;
        this.cache = cache;
    }
    async getAccountInfo(publicKey, commitmentOrConfig) {
        const key = `getAccountInfo_${publicKey.toBase58()}_${commitmentOrConfig}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getAccountInfo(publicKey, commitmentOrConfig))));
    }
    async getConfirmedSignaturesForAddress2(address, options, commitment) {
        const key = `getConfirmedSignaturesForAddress2_${address.toBase58()}_${JSON.stringify(options)}_${commitment}}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getConfirmedSignaturesForAddress2(address, options, commitment))));
    }
    async getLatestBlockhash(commitmentOrConfig) {
        const key = `getLatestBlockhash_${commitmentOrConfig}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getLatestBlockhash(commitmentOrConfig))));
    }
    async getMultipleAccountsInfo(publicKeys, commitmentOrConfig) {
        const key = `getMultipleAccountsInfo_${publicKeys
            .map((pk) => pk.toBase58)
            .join("_")}_${JSON.stringify(commitmentOrConfig)}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getMultipleAccountsInfo(publicKeys, commitmentOrConfig))));
    }
    async getProgramAccounts(programId, configOrCommitment) {
        const key = `getProgramAccounts_${programId.toBase58()}_${JSON.stringify(configOrCommitment)}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getProgramAccounts(programId, configOrCommitment))));
    }
    async getRecentBlockhash(commitment) {
        const key = `getRecentBlockhash_${commitment}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getRecentBlockhash(commitment))));
    }
    async getSlot(commitmentOrConfig) {
        const key = `getSlot_${commitmentOrConfig}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getSlot(commitmentOrConfig))));
    }
    async getTokenAccountBalance(tokenAddress, commitment) {
        const key = `getTokenAccountBalance_${tokenAddress.toBase58()}_${commitment}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getTokenAccountBalance(tokenAddress, commitment))));
    }
    async getTokenSupply(tokenMintAddress, commitment) {
        const key = `getTokenSupply_${tokenMintAddress.toBase58()}_${commitment}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getTokenSupply(tokenMintAddress, commitment))));
    }
    async getTransaction(signature, rawConfig) {
        const key = `getTransaction_${signature}_${JSON.stringify(rawConfig)}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getTransaction(signature, rawConfig))));
    }
    // This does not make sense to cache, so we don't
    async sendTransaction(transaction, options) {
        return await this.connection.sendTransaction(transaction, options);
    }
    async simulateTransaction(transaction, config) {
        const key = `simulateTransaction_${JSON.stringify(transaction)}_${JSON.stringify(config)}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.simulateTransaction(transaction, config))));
    }
    async getAddressLookupTable(accountKey, config) {
        const key = `getAddressLookupTable_${accountKey.toBase58()}_${JSON.stringify(config)}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getAddressLookupTable(accountKey, config))));
    }
    async confirmTransaction(strategy, commitment) {
        const key = `confirmTransaction_${JSON.stringify(strategy)}_${commitment}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.confirmTransaction(strategy, commitment))));
    }
    async getSignatureStatus(signature, config) {
        const key = `getSignatureStatus_${signature}_${JSON.stringify(config)}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getSignatureStatus(signature, config))));
    }
    async getSignatureStatuses(signatures, config) {
        const key = `getSignatureStatuses_${signatures
            .map((sig) => sig)
            .join("_")}_${JSON.stringify(config)}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getSignatureStatuses(signatures, config))));
    }
    async getSignaturesForAddress(address, options, commitment) {
        const key = `getSignaturesForAddress_${address.toBase58()}_${JSON.stringify(options)}_${commitment}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getSignaturesForAddress(address, options, commitment))));
    }
    async getBlocks(startSlot, endSlot, commitment) {
        const key = `getBlocks_${startSlot}_${endSlot}_${commitment}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getBlocks(startSlot, endSlot, commitment))));
    }
    async getFeeForMessage(message, commitment) {
        const key = `getFeeForMessage_${JSON.stringify(message)}_${commitment}`;
        return ((await this.cache.get(key)) ||
            (await this.cache.set(key, this.connection.getFeeForMessage(message, commitment))));
    }
}
exports.CachedConnection = CachedConnection;
